
$('#play').on('click', function() {
  $('#banner').css('display', 'block');

  var playerOne = true;
  $('.row1').on('click', function(e) {
    var columnClass = e.originalEvent.path[0].classList[1]; 

    var element;
    var elementClass;
    for (var i = 0; i < 6; i++) {
      
      var rowNum = 6 - i; 

      element = $('.row' + rowNum + ' .' + columnClass)
      element = element[0];
      elementClass = element.classList;
      var open = true;

      elementClass.forEach(function(element) {
        if (element == 'red' || element == 'yellow') {
          open = false;
        }
      })

      if (open) break;
    }

    if (playerOne == true) {
      $(element).addClass('red');
      playerOne = false;
    } else if (playerOne == false) {
      $(element).addClass('yellow'); 
      playerOne = true;
    }

    checkWinner(element);    
  })
})

function checkWinner(element) {
  // Check winner here
  var element = element;
  var parent = $(element).parent()[0];
}
